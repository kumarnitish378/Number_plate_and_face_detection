+------------------------------------------------------------+
| Use Setup.txt to install requirements.                     |
| Note: You might be face some Error. During Installation    |
| or                                                         |
| Executing code/program.                                       |
| If any you can ping me.                                       |
| Address: nitish.ns378@gmail.Com                               |
| Telegram: 7631256855                                          
+-------------------------------------------------------+
Date: 2021-12-16
Author: Nitish Kumar Sharma
Email: nitish.ns378@gmail.com

License: MIT
MIT License (c) 2021 Nitish Kumar Sharma
This code is licensed under the MIT license (see LICENSE.txt for details)
You are free to use this code in your own projects, as long as you give credit to the original author.
all rights reserved. by Nitish Kumar Sharma

Note: This code is not optimized for performance. only for learning purpose. and it is not tested for performance.
    you may get some error in the code. if any error please let me know. 
    Telegram No: 7631256855
    Email: nitish.ns378@gmail.com

+-------------------------------------------------------+


+-------------------------------------------------------+
Some Command that works, 
1. For face detection from image Run
    >>  python3 image_face_detection.py
            or
    >> sudo python3 image_face_detection.py

+-------------------------------------------------------+
2. For Live face detection:
    >> python3 Live_face_detection.py
                or
    >> sudo python3 Live_face_detection.py

+-------------------------------------------------------+
3. For Number plate detection from image:
    >> python3 number_plate_detection.py
                or
    >> sudo python3 number_plate_detection.py

+-------------------------------------------------------+
4. For live number_plate_detection:
    >> python3 Live_number_plate_detection.py
            or
    >> sudo python3 Live_number_plate_detection.py

+-------------------------------------------------------+
5. For Both Live_number_plate_detection and Live_face_detection:
    >> python3 Live_Number_plate_and_face_detection.py
            or
    >> python3 python3 Live_Number_plate_and_face_detection.py

+-------------------------------------------------------+
6. For Testing or experint. if you want play with code:
    >> python3 Testing_of_number_plate_detection.py
            or
    >> sudo python3 Testing_of_number_plate_detection.py
+-------------------------------------------------------+


Thank you!
Nitish Kumar Sharma